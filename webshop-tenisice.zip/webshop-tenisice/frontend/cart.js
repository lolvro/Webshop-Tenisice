function dohvatiKosaricu() {
    return JSON.parse(localStorage.getItem('kosarica')) || [];
}

function spremiKosaricu(kosarica) {
    localStorage.setItem('kosarica', JSON.stringify(kosarica));
}

function dodajUKosaricu(id, naziv, cijena) {
    const kosarica = dohvatiKosaricu();

    const postojeci = kosarica.find(p => p.id === id);

    if (postojeci) {
        postojeci.kolicina += 1;
    } else {
        kosarica.push({
            id,
            naziv,
            cijena,
            kolicina: 1
        });
    }

    spremiKosaricu(kosarica);
    alert("Proizvod je dodan u košaricu.");
}

function prikaziKosaricu() {
    const container = document.getElementById("kosarica");
    const ukupnoEl = document.getElementById("ukupno");
    const kosarica = dohvatiKosaricu();

    container.innerHTML = '';

    if (kosarica.length === 0) {
        container.innerHTML = '<p>Košarica je prazna.</p>';
        ukupnoEl.textContent = '';
        return;
    }

    let ukupno = 0;

    kosarica.forEach(p => {
        ukupno += p.cijena * p.kolicina;

        container.innerHTML += `
            <div>
                <strong>${p.naziv}</strong><br>
                Cijena: ${p.cijena} €<br>
                Količina: ${p.kolicina}
                <button onclick="ukloniIzKosarice(${p.id})">Ukloni</button>
            </div>
            <hr>
        `;
    });

    ukupnoEl.textContent = `Ukupno: ${ukupno.toFixed(2)} €`;
}

function ukloniIzKosarice(id) {
    let kosarica = dohvatiKosaricu();
    kosarica = kosarica.filter(p => p.id !== id);
    spremiKosaricu(kosarica);
    prikaziKosaricu();
}
prikaziKosaricu();
